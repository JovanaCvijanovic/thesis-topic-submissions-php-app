﻿ <?php
        
		//session_start();  
	   // citanje vrednosti iz sesije - da bismo uvek proverili da li je to prijavljeni korisnik
	   //$idkorisnika=$_SESSION["idkorisnika"];
	   
	      // -------------------------------------
		// UPLOAD FAJLA SLIKE

		$name = $_FILES["nazivFajlaFotografije"]["name"];
		//$size = $_FILES['nazivFajlaFotografije']['size']
		//$type = $_FILES['nazivFajlaFotografije']['type']
		$tmp_name = $_FILES['nazivFajlaFotografije']['tmp_name'];
		$error = $_FILES['nazivFajlaFotografije']['error'];

		if (isset ($name)) {
			if (!empty($name)) {
						$location = 'SlikeStudenata/';
						if  (move_uploaded_file($tmp_name, $location.$name)){
									//echo 'Uploaded';    
						}
					} else {
							//echo 'please choose a file';
							}
					}
	   
	   // preuzimanje vrednosti sa forme
	   $BrojIndeksa=$_POST['BrojIndeksa'];
	   $Prezime=$_POST['prezime'];
	   $Ime=$_POST['ime'];
	   $SifraDiplomskog=$_POST['sifraDiplomskog'];
	   $NazivFajlaFotografije=$name;
	   $NazivTeme=$_POST['NazivTeme'];
	   $NazivTemeNaEngleskom=$_POST['NazivTemeNaEngleskom'];
	   $DatumPrijaveTeme=$_POST['DatumPrijaveTeme'];
	   $Predmet=$_POST['Predmet'];
	   
	   //KONEKCIJA KA SERVERU
	
// koristimo klasu za poziv procedure za konekciju
	require "klase/BaznaKonekcija.php";
	require "klase/BaznaTabela.php";
	$KonekcijaObject = new Konekcija('klase/BaznaParametriKonekcije.xml');
	$KonekcijaObject->connect();
	if ($KonekcijaObject->konekcijaDB) // uspesno realizovana konekcija ka DBMS i bazi podataka
    {	
		//echo "USPESNA KONEKCIJA";
		require "klase/BaznaTransakcija.php";
		$TransakcijaObject = new Transakcija($KonekcijaObject);
		$TransakcijaObject->ZapocniTransakciju();
		
		require "klase/DBPrijavaSP.php";
		$StudentObject = new DBPrijava($KonekcijaObject, 'prijava');
		$StudentObject->BrojIndeksa=$BrojIndeksa;
		$StudentObject->Prezime=$Prezime;
		$StudentObject->Ime=$Ime;
		$StudentObject->SifraDiplomskog=$SifraDiplomskog;
		$StudentObject->NazivFajlaFotografije=$NazivFajlaFotografije;
		$StudentObject->NazivTeme=$NazivTeme;
		$StudentObject->NazivTemeNaEngleskom=$NazivTemeNaEngleskom;
		$StudentObject->DatumPrijaveTeme=$DatumPrijaveTeme;
		$StudentObject->Predmet=$Predmet;
		$greska1=$StudentObject->DodajNovogStudenta();
		
		// inkrement broja studenata kroz klasu DBSmer
		require "klase/DBStanje.php";
		$DiplomskiObject = new DBStanje($KonekcijaObject, 'stanje');
		$greska2=$DiplomskiObject->InkrementirajBrojStudenata($SifraDiplomskog);
		
		// zatvaranje transakcije
		$UtvrdjenaGreska=$greska1 or $greska2;
		$UtvrdjenaGreska=$greska1.$greska2;
		$TransakcijaObject->ZavrsiTransakciju($UtvrdjenaGreska);
        	
		} // od if db selected

      // ZATVARANJE KONEKCIJE KA DBMS
	  $KonekcijaObject->disconnect();
	
	// prikaz uspeha aktivnosti	
	
	if ($UtvrdjenaGreska) {
	echo "Greska $UtvrdjenaGreska";	
     }	
	 else
	 {
		//echo "Snimljeno!";	
		header ('Location:PrijavaLista.php');		
	 }
		
	  
      ?>

