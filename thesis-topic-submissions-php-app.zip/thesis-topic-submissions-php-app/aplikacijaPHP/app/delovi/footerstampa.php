﻿<meta charset="UTF-8">
<tr style="padding:0px;">
<td style="width:10%;"></td>
<td align="center" valign="middle" bgcolor="#FFFFFF"><font face="Trebuchet MS" color="black" size="2px"> Јована Аврамов * * *  Контакт e-mail: jovanaavramov@gmail.com</font></td>
<td style="width:10%;"></td>
</tr>