
<meta charset="UTF-8">
<!--==================================== SADRZAJ STRANICE DESNO pocinje ovde ------------------------------>
<img src="images/sredinagore.jpg" width="100%" height="3" alt="" class="flt1 rp_topcornn" /> 

<table style="width:100%;style="width:100%; padding:0" align="center" cellspacing="0" cellpadding="0" border="0"  bgcolor="#D8E7F4">

<tr>
<td style="width:5%;">
</td>

<td>
<font face="Trebuchet MS" color="darkblue" size="4px">
</br>
<b>ПАРАМЕТАРСКА ШТАМПА</br> </font>
</br>
<form action="StampaPodatakaOPrijavi.php" method="POST">
Број индекса: <input type="text" name="BrojIndeksaFilter" />
<input type="submit" name="stampaj" value="ШТАМПАЈ" />
</form>


</td>

<td style="width:5%;">
</td>
</tr>


<tr>
<td style="width:5%;">
</td>

<td align="left">
<br/>
<font face="Trebuchet MS" color="darkblue" size="4px">


</td>

<td style="width:5%;">
</td>

</tr>
</table>

    