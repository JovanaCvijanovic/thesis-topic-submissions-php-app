
<meta charset="UTF-8">
<table style="width:100%;" bgcolor="#003366">
<tr>
<td style="width:1%;">
</td>
<td align="left" valign="middle">
<font face="Trebuchet MS" color="darkblue" size="2px"><a href="index.php">Почетна</a> </font>
</td>
<td style="width:50%;">
</td>
<td > 
</td>
<td style="width:1%;">
</td>
</tr>
</table>