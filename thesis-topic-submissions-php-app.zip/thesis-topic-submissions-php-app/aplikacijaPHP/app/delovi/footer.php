﻿<meta charset="UTF-8">
<tr style="padding:0px;">
<td style="width:10%;"></td>
<td align="center" valign="middle" bgcolor="#003366"><font face="Trebuchet MS" color="white" size="2px">Copyright: Јована Аврамов * * *  Контакт e-mail:<a href=/"mailto: jovanaavramov@gmail.com/">jovanaavramov@gmail.com</a> </font></td>
<td style="width:10%;"></td>
</tr>