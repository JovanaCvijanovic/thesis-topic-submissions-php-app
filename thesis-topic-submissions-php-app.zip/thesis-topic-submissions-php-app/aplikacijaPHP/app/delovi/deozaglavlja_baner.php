
<meta charset="UTF-8">
<table style="width:100%; height=100% padding:0" align="center" cellspacing="0" cellpadding="0" border="0" background="images/baner.jpg" no-repeat>
<tr>
<td><font color="white" size="1px">.</font>
</td>
<td>
</td>
<td>
</td>
</tr>

<tr>
<td><font color="white" size="1px">.</font>
</td>
<td>
</td>
<td>
</td>
</tr>

<tr>
<td style="width:5%;">
</td>
<td align="center">
 <div class="flt1 topblock"> <a href="index.php" class="flt1 tp_txtplay">&nbsp;&nbsp;&nbsp;Дипломски радови</a></br> 
 <span class="flt1 tp_txtcss">Технички факултет Михајло Пупин</span>
</td>
<td style="width:20%;">
</td>
</tr>

<tr>
<td><font color="white" size="1px">.</font>
</td>
<td>
</td>
<td>
</td>
</tr>

<tr>
<td><font color="white" size="1px">.</font>
</td>
<td>
</td>
<td>
</td>
</tr>

</table>
