<meta charset="UTF-8">
<!------- MENI LEVO ----------->
<table style="width:100%; padding:0" align="center" cellspacing="0" cellpadding="0" border="0">
<tr>
<td>
</br>
</td>
</tr>

<!---------------------- VESTI pocinje ovde ----------------------> 
<tr>
<td valign="top" align="center"> 
<table style="width:100%;" bgcolor="#B7F3FE"  align="center" cellspacing="0" cellpadding="0" border="0">

<tr bgcolor="#FFFFFF">
<td style="width:2px; border: 1px solid white;">
</td>
<td style="border: 1px solid white;">
</td>
<td style="width:2px;border: 1px solid white;">
</td>
</tr>


<tr>
<td style="width:2px;border: 1px solid white;background-color: white;">
</td>
<td style="border: 1px solid white;">

<table style="width:100%;" bgcolor="#B7F3FE"  align="center" cellspacing="0" cellpadding="0" border="0">

<tr>
<td style="width:1px;">
</td>
<td style="align:center">
&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; </br>
</td>
<td>
</td>
<td style="width:1px;">
</td>
</tr>

<tr>
<td style="width:1px;">
</td>
<td style="align:center">
<font face="Trebuchet MS" color="black" size="4px">&nbsp;&nbsp;СТУДЕНТ:</font></b></br>
</td>
<td>
</td>
<td style="width:1px;">
</td>
</tr>


<tr>
<td style="width:1px;">
</td>
<td style="align:center">
 <a href="index.php" ><font face="Trebuchet MS" color="black" size="2px">&nbsp;&nbsp;Почетна</font></a>
</td>
<td>
</td>
<td style="width:1px;">
</td>
</tr>



<tr>
<td style="width:1px;">
</td>
<td style="align:center">
 <a href="unoskorisnik.php" ><font face="Trebuchet MS" color="black" size="2px">&nbsp;&nbsp;Унос</font></a>
</td>
<td>
</td>
<td style="width:1px;">
</td>
</tr>

<tr>
<td style="width:1px;">
</td>
<td style="align:center">
 <a href="tabelarniprikaz.php" ><font face="Trebuchet MS" color="black" size="2px">&nbsp;&nbsp;Табеларни приказ</font></a>
</td>
<td>
</td>
<td style="width:1px;">
</td>
</tr>


<tr>
<td style="width:1px;">
</td>
<td style="align:center">
 <a href="stampa.php" ><font face="Trebuchet MS" color="black" size="2px">&nbsp;&nbsp;Штампа</font></a>
</td>
<td>
</td>
<td style="width:1px;">
</td>
</tr>


<tr>
<td style="width:1px;">
</td>
<td style="align:center">
 <a href="parametarskastampa.php" ><font face="Trebuchet MS" color="black" size="2px">&nbsp;&nbsp;Параметарска штампа</font></a>
</td>
<td>
</td>
<td style="width:1px;">
</td>
</tr>


<tr>
<td style="width:1px;">
</td>
<td style="align:center">
&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; </br>
</td>
<td>
</td>
<td style="width:1px;">
</td>
</tr>


</table>
</td>

<td style="width:2px;border: 1px solid white;background-color: white;">
</td>
</tr>

<tr bgcolor="#FFFFFF">
<td style="width:2px; border: 1px solid white;">
</td>
<td style="border: 1px solid white;">
</td>
<td style="width:2px;border: 1px solid white;">
</td>
</tr>

</table>

</td>
</tr>
<!---------------------- VESTI zavrsava ovde ---------------------->  



<!---------------------- AUTOR pocinje ovde ----------------------> 
<tr>
<td valign="top" align="center"> 
<table style="width:100%;" bgcolor="#B7F3FE"  align="center" cellspacing="0" cellpadding="0" border="0">

<tr bgcolor="#FFFFFF">
<td style="width:2px; border: 1px solid white;">
</td>
<td style="border: 1px solid white;">
</td>
<td style="width:2px;border: 1px solid white;">
</td>
</tr>


<tr>
<td style="width:2px;border: 1px solid white;background-color: white;">
</td>
<td style="border: 1px solid white;">

<table style="width:100%;" bgcolor="#B7F3FE" align="center" cellspacing="0" cellpadding="0" border="0">

<tr>
<td style="width:1px;">
</td>
<td style="align:center">
&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; </br>
</td>
<td>
</td>
<td style="width:1px;">
</td>
</tr>

<tr>
<td style="width:1px;">
</td>
<td style="align:center">
<font face="Trebuchet MS" color="black" size="4px">&nbsp;&nbsp;АУТОР:</font></b></br>
</td>
<td>
</td>
<td style="width:1px;">
</td>
</tr>

<tr>
<td style="width:1px;">
</td>
<td style="align:center">
 <font face="Trebuchet MS" color="black" size="2px">&nbsp;&nbsp;Јована Аврамов</font>
</td>
<td>
</td>
<td style="width:1px;">
</td>
</tr>

<tr>
<td style="width:1px;">
</td>
<td style="align:center">
 <font face="Trebuchet MS" color="black" size="2px">&nbsp;&nbsp;E-mail:</font>
</td>
<td>
</td>
<td style="width:1px;">
</td>
</tr>

<tr>
<td style="width:1px;">
</td>
<td style="align:center">
 <font face="Trebuchet MS" color="black" size="2px">&nbsp;&nbsp;jovanaavramov@gmail.com</font>
</td>
<td>
</td>
<td style="width:1px;">
</td>
</tr>


<tr>
<td style="width:1px;">
</td>
<td style="align:center">
&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; </br>
</td>
<td>
</td>
<td style="width:1px;">
</td>
</tr>

</table>
</td>

<td style="width:2px;border: 1px solid white;background-color: white;">
</td>
</tr>

<tr bgcolor="#FFFFFF">
<td style="width:2px; border: 1px solid white;">
</td>
<td style="border: 1px solid white;">
</td>
<td style="width:2px;border: 1px solid white;">
</td>
</tr>

</table>

</td>
</tr>
<!---------------------- VLASNIK zavrsava ovde ---------------------->  


</table>

<!------- MENI LEVO zavrsava ovde ----------->  