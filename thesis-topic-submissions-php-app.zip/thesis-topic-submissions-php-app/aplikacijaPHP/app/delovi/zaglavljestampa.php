
<meta charset="UTF-8">
<tr>
<td style="width:10%;">
</td>
<td align="center" valign="middle"> 
<b><font face="Trebuchet MS" color="darkblue" size="3px">Дипломски радови</font></b>
</td>
<td style="width:10%;">
</td>
</tr>

<tr>
<td style="width:10%;">
</td>
<td align="center" valign="middle"> 
<b><font face="Trebuchet MS" color="darkblue" size="3px">Технички факултет Михајло Пупин</font></b>
</td>
<td style="width:10%;">
</td>
</tr>

