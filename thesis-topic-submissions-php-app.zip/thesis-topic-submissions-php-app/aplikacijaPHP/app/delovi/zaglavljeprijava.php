
<meta charset="UTF-8">
<tr>
<td style="width:10%;">
</td>
<td align="center" valign="middle"> 
<?php include 'delovi/deozaglavlja_baner.php';?>
</td>
<td style="width:10%;">
</td>
</tr>

<tr>
<td style="width:10%;">
</td>
<td>
<?php include 'delovi/deozaglavlja_prijava.php';?>
</td>
<td style="width:10%;">
</td>
</tr>

