﻿<meta charset="UTF-8">
<!------- MENI LEVO ----------->
<table style="width:100%; padding:0" align="center" cellspacing="0" cellpadding="0" border="0">
<tr>
<td>
</br>
</td>
</tr>


<tr>
<td valign="top" align="center"> 

<!---------------------- VELIKI PROJEKAT pocinje ovde ----------------------> 
<table style="width:100%;" bgcolor="#B7F3FE" padding:0" align="center" cellspacing="0" cellpadding="0" border="0">

<tr bgcolor="#FFFFFF">
<td style="width:2px; border: 1px solid white;">
</td>
<td style="border: 1px solid white;">
</td>
<td style="width:2px;border: 1px solid white;">
</td>
</tr>


<tr>
<td style="width:2px;border: 1px solid white;background-color: white;">
</td>
<td style="border: 1px solid white;">

<table style="width:100%;" bgcolor="#B7F3FE" padding:0" align="center" cellspacing="0" cellpadding="0" border="0">

<tr>
<td style="width:1px;">
</td>
<td style="align:center">
&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; </br>
</td>
<td>
</td>
<td style="width:1px;">
</td>
</tr>

<tr>
<td style="width:1px;">
</td>
<td style="align:center">
<b><font face="Trebuchet MS" color="black" size="4px">&nbsp;&nbsp;ОПЦИЈЕ</font></b></br>
<hr color="white">
</td>
<td>
</td>
<td style="width:1px;">
</td>
</tr>

<tr>
<td style="width:1px;">
</td>
<td style="align:center">
 <a href="Welcomekorisnik.php" ><b><font face="Trebuchet MS" color="black" size="3px">&nbsp;&nbsp;Насловна</font></b></a>
</td>
<td>
</td>
<td style="width:1px;">
</td>
</tr>


<tr>
<td style="width:1px;">
</td>
<td style="align:center">
 <b><font face="Trebuchet MS" color="black" size="3px">&nbsp;&nbsp;Студенти</font></b>
</td>
<td>
</td>
<td style="width:1px;">
</td>
</tr>

<tr>
<td style="width:1px;">
</td>
<td style="align:center">
 <a href="unoskorisnik.php" ><font face="Trebuchet MS" color="black" size="2px">&nbsp;&nbsp;&nbsp;&nbsp;Додавање</font></a>
</td>
<td>
</td>
<td style="width:1px;">
</td>
</tr>

<tr>
<td style="width:1px;">
</td>
<td style="align:center">
 <a href="unoskorisnikSP.php" ><font face="Trebuchet MS" color="black" size="2px">&nbsp;&nbsp;&nbsp;&nbsp;Додавањe СП</font></a>
</td>
<td>
</td>
<td style="width:1px;">
</td>
</tr>


<tr>
<td style="width:1px;">
</td>
<td style="align:center">
 <a href="PrijavaLista.php" ><font face="Trebuchet MS" color="black" size="2px">&nbsp;&nbsp;&nbsp;&nbsp;Листа и ажурирање</font></a>
</td>
<td>
</td>
<td style="width:1px;">
</td>
</tr>

<tr>
<td style="width:1px;">
</td>
<td style="align:center">
 <a href="PrijaveStampa.php" ><font face="Trebuchet MS" color="black" size="2px">&nbsp;&nbsp;&nbsp;&nbsp;Штампа</font></a>
</td>
<td>
</td>
<td style="width:1px;">
</td>
</tr>

<tr>
<td style="width:1px;">
</td>
<td style="align:center">
 <a href="PrijaveParametarskaStampa.php" ><font face="Trebuchet MS" color="black" size="2px">&nbsp;&nbsp;&nbsp;&nbsp;Параметарска штампа</font></a>
</td>
<td>
</td>
<td style="width:1px;">
</td>
</tr>


<tr>
<td style="width:1px;">
</td>
<td style="align:center">
&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; </br>
</td>
<td>
</td>
<td style="width:1px;">
</td>
</tr>

</table>
</td>

<td style="width:2px;border: 1px solid white;background-color: white;">
</td>
</tr>

<tr bgcolor="#FFFFFF">
<td style="width:2px; border: 1px solid white;">
</td>
<td style="border: 1px solid white;">
</td>
<td style="width:2px;border: 1px solid white;">
</td>
</tr>

</table>
<!---------------------- VELIKI PROJEKAT zavrsava ovde ---------------------->  
</td>
</tr>



</table>

<!------- MENI LEVO zavrsava ovde ----------->  