<?php
class DBPrijava extends Tabela 
{
// ATRIBUTI
private $bazapodataka;
private $UspehKonekcijeNaDBMS;
//
public $BrojIndeksa;
public $Prezime;
public $Ime;
public $SifraDiplomskog;
public $NazivFajlaFotografije;
public $NazivTeme;
public $NazivTemeNaEngleskom;
public $DatumPrijaveTeme;
public $Predmet;

// METODE

// konstruktor

public function DajKolekcijuSvihStudenata()
{
$SQL = "select * from `prijava` ORDER BY prezime ASC";
$this->UcitajSvePoUpitu($SQL); // puni atribut bazne klase Kolekcija
return $this->Kolekcija; // uzima iz baznek klase vrednost atributa
}

public function UcitajStudentaPoBrojuIndeksa($BrojIndeksaParametar)
{
$SQL = "select * from `prijava` where `BrojIndeksa`='".$BrojIndeksaParametar."'";
$this->UcitajSvePoUpitu($SQL); // puni atribut bazne klase Kolekcija
// raspolazemo sa:
// $Kolekcija;
//  $BrojZapisa;
}

public function DodajNovogStudenta()
{
	$SQL = "INSERT INTO `prijava` (BrojIndeksa, Prezime, Ime, SifraDiplomskog, NazivFajlaFotografije, NazivTeme, NazivTemeNaEngleskom, DatumPrijaveTeme, Predmet) VALUES ('$this->BrojIndeksa','$this->Prezime', '$this->Ime', '$this->SifraDiplomskog', '$this->NazivFajlaFotografije', '$this->NazivTeme', '$this->NazivTemeNaEngleskom', '$this->DatumPrijaveTeme', '$this->Predmet')";
	$greska=$this->IzvrsiAktivanSQLUpit($SQL);
	
	return $greska;
}




public function ObrisiStudenta($IdZaBrisanje)
{
	$SQL = "DELETE FROM `prijava` WHERE BrojIndeksa='".$IdZaBrisanje."'";
	$greska=$this->IzvrsiAktivanSQLUpit($SQL);
	
	return $greska;
}

// TO DO

public function IzmeniStudenta($StariBrojIndeksa, $BrojIndeksa, $prezime, $ime, $sifraDiplomskog, $nazivFajlaFotografije, $nazivTeme, $nazivTemeNaEngleskom, $datumPrijaveTeme, $predmet)
{
	$SQL = "UPDATE `prijava` SET BrojIndeksa='".$BrojIndeksa."', Prezime='".$prezime."', Ime='".$ime."', SifraDiplomskog='".$sifraDiplomskog."', NazivFajlaFotografije='".$nazivFajlaFotografije."' , NazivTeme='".$nazivTeme."' , NazivTemeNaEngleskom='".$nazivTemeNaEngleskom."' , DatumPrijaveTeme='".$datumPrijaveTeme."', Predmet='".$predmet."' WHERE BrojIndeksa='".$StariBrojIndeksa."'";
	$greska=$this->IzvrsiAktivanSQLUpit($SQL);
	
	return $greska;
}

// ostale metode 




}
?>