<?php
class DBStanje extends Tabela 
{
// ATRIBUTI
private $bazapodataka;
private $UspehKonekcijeNaDBMS;
//
public $Sifra;
public $StanjeDiplomskog; 
public $UkupanBrojStudenata;

// METODE

// konstruktor

public function UcitajKolekcijuSvihDiplomskih()
{
$SQL = "select * from `Stanje` ORDER BY StanjeDiplomskog ASC";
$this->UcitajSvePoUpitu($SQL); // puni atribut bazne klase Kolekcija
//return $this->Kolekcija; // uzima iz baznek klase vrednost atributa
}

public function InkrementirajBrojStudenata($IDStanja)
{
	// izdvajanje stare vrednosti  
	
	$KriterijumFiltriranja="Sifra='".$IDStanja."'";
	$StaraVrednostUkBrStudenata=$this->DajVrednostJednogPoljaPrvogZapisa ('UkupanBrojStudenata', $KriterijumFiltriranja, 'UkupanBrojStudenata'); 
	
	// izracunavanje nove vrednosti
	$NovaVrednostUkBrStudenata=$StaraVrednostUkBrStudenata + 1;
	
	// izvrsavanje izmene
    $SQL = "UPDATE `".$this->NazivBazePodataka."`.`stanje` SET UkupanBrojStudenata=".$NovaVrednostUkBrStudenata." WHERE Sifra='".$IDStanja."'";
	$greska= $this->IzvrsiAktivanSQLUpit($SQL);

	return $greska;
	
	}

// ########### TO DO



// ostale metode 




}
?>