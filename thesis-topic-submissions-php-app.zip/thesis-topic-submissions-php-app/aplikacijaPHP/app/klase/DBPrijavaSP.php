<?php
class DBPrijava extends Tabela 
// rad sa stored procedurom za snimanje novog studenta
{
// ATRIBUTI
private $bazapodataka;
private $UspehKonekcijeNaDBMS;
//
public $BrojIndeksa;
public $Prezime;
public $Ime;
public $SifraDiplomskog;
public $NazivFajlaFotografije;
public $NazivTeme;
public $NazivTemeNaEngleskom;
public $DatumPrijaveTeme;
public $Predmet;

// METODE

// konstruktor

public function DodajNovogStudenta()
{
	//$SQL = "INSERT INTO `student` (BrojIndeksa, Prezime, Ime, OznakaSmera, NazivFajlaFotografije) VALUES ('$this->BrojIndeksa','$this->Prezime', '$this->Ime', '$this->OznakaSmera', '$this->NazivFajlaFotografije')";
	//$greska=$this->IzvrsiAktivanSQLUpit($SQL);
	
	
		$GreskarezultatPar1 = $this->IzvrsiAktivanSQLUpit ("SET @BrojIndeksaParametar='".$this->BrojIndeksa."'");
		
		$GreskarezultatPar2 = $this->IzvrsiAktivanSQLUpit ("SET @PrezimeParametar='".$this->Prezime."'");
		
		$GreskarezultatPar3 =  $this->IzvrsiAktivanSQLUpit ("SET @ImeParametar='".$this->Ime."'");
		
		$GreskarezultatPar4 = $this->IzvrsiAktivanSQLUpit (  "SET @SifraDiplomskogParametar='".$this->SifraDiplomskog."'");
		
		$GreskarezultatPar5 = $this->IzvrsiAktivanSQLUpit (  "SET @NazivFajlaFotografijeParametar='".$this->NazivFajlaFotografije."'");

		$GreskarezultatPar6 = $this->IzvrsiAktivanSQLUpit (  "SET @NazivTemeParametar='".$this->NazivTeme."'");

		$GreskarezultatPar7 = $this->IzvrsiAktivanSQLUpit (  "SET @NazivTemeNaEngleskomParametar='".$this->NazivTemeNaEngleskom."'");

		$GreskarezultatPar8 = $this->IzvrsiAktivanSQLUpit (  "SET @DatumPrijaveTemeParametar='".$this->DatumPrijaveTeme."'");

		$GreskarezultatPar9 = $this->IzvrsiAktivanSQLUpit (  "SET @PredmetParametar='".$this->Predmet."'");
		
		$GreskarezultatCall = $this->IzvrsiAktivanSQLUpit ( "CALL `DodajStudenta`(@BrojIndeksaParametar,@PrezimeParametar,@ImeParametar,@SifraDiplomskogParametar,@NazivFajlaFotografijeParametar, @NazivTemeParametar, @NazivTemeNaEngleskomParametar, @DatumPrijaveTemeParametar, @PredmetParametar);");
		
	
	$greska=$GreskarezultatPar1.$GreskarezultatPar2.$GreskarezultatPar3.$GreskarezultatPar4.$GreskarezultatPar5.$GreskarezultatPar6.$GreskarezultatPar7.$GreskarezultatPar8.$GreskarezultatPar9.$GreskarezultatCall;
	return $greska;
}


}
?>