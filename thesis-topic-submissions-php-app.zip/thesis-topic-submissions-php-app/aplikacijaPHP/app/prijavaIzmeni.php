 <?php
        
		session_start();  
	   // citanje vrednosti iz sesije - da bismo uvek proverili da li je to prijavljeni admin$admin
	   // citanje vrednosti iz sesije - da bismo uvek proverili da li je to prijavljeni admin$admin
	   $korisnik=$_SESSION["korisnik"];
      
	  // ako nije prijavljen admin$admin, vraca ga na pocetnu stranicu
				if (!isset($korisnik))
				{
					header ('Location:index.php');
				}	
	   

	      // -------------------------------------
		// UPLOAD FAJLA SLIKE

		if (isset($_FILES["nazivFajlaFotografije"]["name"]))
		{
			$name = $_FILES["nazivFajlaFotografije"]["name"];
			//$size = $_FILES['nazivFajlaFotografije']['size']
			//$type = $_FILES['nazivFajlaFotografije']['type']
			$tmp_name = $_FILES['nazivFajlaFotografije']['tmp_name'];
			$error = $_FILES['nazivFajlaFotografije']['error'];
	
			if (isset ($name)) {
				if (!empty($name)) {
							$location = 'SlikeStudenata/';
							if  (move_uploaded_file($tmp_name, $location.$name)){
										//echo 'Uploaded';    
							}
						} else {
								//echo 'please choose a file';
								}
						} 
			$nazivFajlaFotografije=$name;
		}
		else // ako nije nista promenjeno
		{
			$StariNazivFajlaFotografije=$_POST['StariNazivFajlaFotografije'];
			$nazivFajlaFotografije=$StariNazivFajlaFotografije;
		}

	   // preuzimanje vrednosti sa forme
	   $BrojIndeksa=$_POST['BrojIndeksa'];
	   $StariBrojIndeksa=$_POST['StariBrojIndeksa'];
	   $prezime=$_POST['prezime'];
	   $ime=$_POST['ime'];
	   $nazivTeme=$_POST['nazivTeme'];
	   $nazivTemeNaEngleskom=$_POST['nazivTemeNaEngleskom'];
	   $datumPrijaveTeme=$_POST['datumPrijaveTeme'];
	   $predmet=$_POST['predmet'];

	   if (isset($_POST['sifraDiplomskog']))
	   {
		$sifraDiplomskog=$_POST['sifraDiplomskog'];
	   }
	   else // ako nije nista promenjeno
	   {
		$StaraSifraDiplomskog=$_POST['StaraSifraDiplomskog'];
		$sifraDiplomskog=$StaraSifraDiplomskog;
	   }
	  
	   // koristimo klasu za poziv procedure za konekciju
		require "klase/BaznaKonekcija.php";
		require "klase/BaznaTabela.php";
		$KonekcijaObject = new Konekcija('klase/BaznaParametriKonekcije.xml');
		$KonekcijaObject->connect();
		if ($KonekcijaObject->konekcijaDB) // uspesno realizovana konekcija ka DBMS i bazi podataka
		{	
			require "klase/DBPrijava.php";
			$StudentObject = new DBPrijava($KonekcijaObject, 'prijava');
			$greska=$StudentObject->IzmeniStudenta($StariBrojIndeksa, $BrojIndeksa, $prezime, $ime, $sifraDiplomskog, $nazivFajlaFotografije, $nazivTeme, $nazivTemeNaEngleskom, $datumPrijaveTeme, $predmet);
		}
		else
		{
			echo "Nije uspostavljena konekcija ka bazi podataka!";
		}
		
    $KonekcijaObject->disconnect();
	   
	// prikaz uspeha aktivnosti	
	//echo "Ukupno procesirano $retval zapisa";
	//echo "Greska $greska";	

	header ('Location:PrijavaLista.php');	
		
	  
      ?>

